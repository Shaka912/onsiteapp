//
//  DateSelectViewController.swift
//  CreditCardAppDraft3
//
//  Created by Apple on 30/01/2023.
//

import UIKit

class DateSelectViewController: UIViewController {
    var finalEmail = ""
    var finalFirstN = ""
    var finalLastN = ""
    var phonenums = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
