//
//  OtpViewController.swift
//  CreditCardAppDraft3
//
//  Created by Apple on 30/01/2023.
//

import UIKit
import OTPFieldView

class OtpViewController: UIViewController {
    var otpTextFieldView: OTPFieldView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupOtpView()
        
        view.addSubview(otpTextFieldView)
    }
    
    func setupOtpView(){
            otpTextFieldView = OTPFieldView(frame: CGRect(x: 40, y: 290, width: 300, height: 100))
            self.otpTextFieldView.fieldsCount = 6
            self.otpTextFieldView.fieldBorderWidth = 2
            self.otpTextFieldView.defaultBorderColor = UIColor.black
            self.otpTextFieldView.filledBorderColor = UIColor.orange
            self.otpTextFieldView.cursorColor = UIColor.red
            self.otpTextFieldView.displayType = .underlinedBottom
            self.otpTextFieldView.fieldSize = 40
            self.otpTextFieldView.separatorSpace = 8
            self.otpTextFieldView.shouldAllowIntermediateEditing = false
//            self.otpTextFieldView.delegate = self
            self.otpTextFieldView.initializeUI()
        }
    
    @IBAction func ContinueOtp(_ sender: Any) {
        
        performSegue(withIdentifier: "EmailSegue", sender: self)
    }
    

}
