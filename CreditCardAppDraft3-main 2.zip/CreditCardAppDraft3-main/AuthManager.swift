//
//  AuthManager.swift
//  CreditCardAppDraft3
//
//  Created by Apple on 30/01/2023.
//

import Foundation
import FirebaseAuth
class AuthManager
{
    static let shared = AuthManager()
    var verificationId : String?
    let auth = Auth.auth()
    init()
    {
        verificationId = nil
    }
    public func startAuth (phoneNumber : String , completion : @escaping (Bool)-> Void) -> String
    {
        PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { [weak self] verificationId, error in
            guard let verificationId = verificationId, error == nil else {
                completion(false)
                return
            }
            self?.verificationId = verificationId
            completion(true)
            
        }
        return verificationId!
    }
    public func verifysms (smscode : String , completion : @escaping (Bool) -> Void){
        
        
        guard let verificationid = verificationId else {
            completion(false)
            return
        }
        
        
        let credential = PhoneAuthProvider.provider().credential(
          withVerificationID: verificationid,
          verificationCode: smscode
        )
        
        
        auth.signIn(with: credential) { AuthDataResult, error in
            guard AuthDataResult != nil , error == nil else
            {
                completion(false)
                return
            }
        }
        
        completion(true)
    }
}
